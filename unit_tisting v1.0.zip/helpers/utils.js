const getFullName = (firstName, lastName) => {
  return firstName + " " + lastName;
};

async function getUser(id) {
  const users = await User.find();
  const user = users.find((user) => user._id == id);

  if (!user) return "can't find user";
  return user;
}
module.exports = {
  getFullName,
};
