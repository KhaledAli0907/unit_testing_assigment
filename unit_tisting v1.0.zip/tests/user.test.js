const it = require("ava").default;
const descripe = require("ava").describe;

const chai = require("chai");
var expect = chai.expect;
const startDB = require("../helpers/DB");
const { MongoMemoryServer } = require("mongodb-memory-server");
const {
  addUser,
  getUsers,
  getSingleUser,
  deleteUser,
} = require("../controllers/user");
const sinon = require("sinon");
const utils = require("../helpers/utils");
const User = require("../models/user");
const { default: mongoose } = require("mongoose");

it.before(async (t) => {
  t.context.mongod = await MongoMemoryServer.create();
  process.env.MONGOURI = t.context.mongod.getUri("itiUnitTesting");
  await startDB();
});

it.after(async (t) => {
  //   await t.context.mongod.stop({ doCleanUp: true });
  mongoose.disconnect();
  t.context.mongod.stop();

});

// it.beforeEach(async () => {
//   // Create test users and save them to the in-memory database
//   const testUser1 = new User({
//     age: 23,
//   });
//   const testUser2 = new User({
//     age: 24,
//   });
//   await testUser1.save();
//   await testUser2.save();
// });

// it.afterEach(async () => {
//   // Remove all users after each test
//   await User.deleteMany({});
// });

it("should create one user", async (t) => {
  // setup
  const fullName = "menna hamdy";
  const request = {
    body: {
      firstName: "menna",
      lastName: "hamdy",
      age: 3,
      job: "developer",
    },
  };
  expectedResult = {
    fullName,
    age: 3,
    job: "developer",
  };
  // exercise
  // sinon.stub(utils, 'getFullName').returns(fullName);
  const stub1 = sinon.stub(utils, "getFullName").callsFake((fname, lname) => {
    expect(fname).to.be.equal(request.body.firstName);
    expect(lname).to.be.equal(request.body.lastName);
    return fullName;
  });
  t.teardown(async () => {
    await User.deleteMany({
      fullName: request.body.fullName,
    });
    stub1.restore();
  });
  const actualResult = await addUser(request);
  // verify
  expect(actualResult._doc).to.deep.equal({
    _id: actualResult._id,
    __v: actualResult.__v,
    ...expectedResult,
  });
  const users = await User.find({
    fullName,
  }).lean();
  expect(users).to.have.length(1);
  expect(users[0]).to.deep.equal({
    _id: actualResult._id,
    __v: actualResult.__v,
    ...expectedResult,
  });
  t.pass();
});

it("should return an array with the same length", async (t) => {
  const request = {};
  const reply = { code: sinon.stub(), send: sinon.stub() };

  const testUser1 = new User({ age: 12 });
  const testUser2 = new User({ age: 5 });
  await testUser1.save();
  await testUser2.save();

  const expectedUsers = await User.find();
  const actualResult = await getUsers(request);
  //   const users = await getUsers(request, reply);
  expect(actualResult).to.have.length(expectedUsers.length);
  //   expect(reply.send).to.({ users: [] });
  t.pass();
});

it("should return a single user", async (t) => {
  const testUser1 = new User({
    age: 23,
  });
  testUser1.save();

  const users = await User.find();
  const userId = users[0]._id.toString();
  const request = { params: { id: userId } };
  const user = await getSingleUser(request);
  console.log(user);
  expect(user._id.toString()).to.be.equal(userId);
  t.pass();
});

it("should return the deleted user", async (t) => {
  const testUser1 = new User({
    age: 23,
  });
  testUser1.save();

  const users = await User.find();
  const userId = users[0]._id.toString();
  const request = { params: { id: userId } };
  const user = await deleteUser(request);
  console.log(user);
  expect(user._id.toString()).to.be.equal(userId);
  t.pass();
});
